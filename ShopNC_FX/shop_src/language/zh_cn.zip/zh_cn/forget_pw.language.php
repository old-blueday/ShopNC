<?php
/////////////////////////////////////////////////////////////////////////////
// 这个文件是 网城创想分销王系统 项目的一部分
//
// Copyright (c) 2007 - 2008 www.shopnc.net 
//
// 要查看完整的版权信息和许可信息，请查看源代码中附带的 COPYRIGHT 文件，
// 或者访问 http://www.shopnc.net/ 获得详细信息。
/////////////////////////////////////////////////////////////////////////////

/**
* FILE_NAME : forget_pw.language.php D:\root\shopnc6_jh\shop_src\language\zh_cn\forget_pw.language.php
* 忘记密码页面forget_pw.html中文语言包
*
* @copyright Copyright (c) 2007 - 2007 www.shopnc.net 
* @author 网城创想分销王系统开发团队 php_netproject@yahoo.com.cn
* @package 
* @subpackage 
* @version Sat Jul 04 11:12:49 CST 2009
*/
	
	$language['forgetpw_title']		= '找回密码';
	$language['forgetpw_user']		= '请输入注册时的用户名';
	$language['forgetpw_email']		= '请输入注册时的E-mail';
	$language['forgetpw_submit']	= '点 我 提 交';
	
?>