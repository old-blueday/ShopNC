<?php
/////////////////////////////////////////////////////////////////////////////
// 这个文件是 网城创想分销王系统 项目的一部分
//
// Copyright (c) 2007 - 2008 www.shopnc.net 
//
// 要查看完整的版权信息和许可信息，请查看源代码中附带的 COPYRIGHT 文件，
// 或者访问 http://www.shopnc.net/ 获得详细信息。
/////////////////////////////////////////////////////////////////////////////

/**
* FILE_NAME : vote.language.php D:\root\shopnc6_jh\shop_src\language\zh_cn\vote.language.php
* 前台投票语言包
*
* @copyright Copyright (c) 2007 - 2007 www.shopnc.net 
* @author 网城创想分销王系统开发团队 php_netproject@yahoo.com.cn
* @package 
* @subpackage 
* @version Sat Jul 04 11:20:03 CST 2009
*/
$language['vote_view_name']		= "投票结果";
$language['vote_view_info']		= "人参与";
$language['vote_view_num']		= "票";

?>