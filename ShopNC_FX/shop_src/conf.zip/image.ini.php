<?php

$INFO['productinfo']['watermark_state']='1';

$INFO['productinfo']['watermark_type']='1';

$INFO['productinfo']['watermark_width']='60';

$INFO['productinfo']['watermark_height']='20';

$INFO['productinfo']['watermark_text']='www.shopnc.net';

$INFO['productinfo']['watermark_text_size']='6';

$INFO['productinfo']['watermark_text_color']='#FF0000';

$INFO['productinfo']['watermark_trans']='60';

$INFO['productinfo']['watermark_site']='3';

$INFO['productinfo']['allowuploadmaxsize']='1024';

$INFO['productinfo']['allowuploadimagetype']='jpg,png,gif';

$INFO['productinfo']['uploadsavetype']='3';

$INFO['productinfo']['image_width']='256';

$INFO['productinfo']['image_height']='256';

$INFO['productinfo']['attachmentspath']='attachments/---image_path---/upimg';

$INFO['productinfo']['watermark_file']='data/---imagename--.jpg';

?>