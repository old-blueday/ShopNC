<?php
$articleClass_cache = array(
 );
?>