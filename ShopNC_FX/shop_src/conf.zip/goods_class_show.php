<?php
$node_cache = array( 

 );
?>