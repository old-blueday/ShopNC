<?php

$currencies_set = array(
					---currency_id---=>array(
						'currencies_id'=>'---currency_id---',
						'currencies_name'=>'人民币',
						'currencies_code'=>'CNY',
						'currencies_symbol'=>'￥',
						'currencies_units'=>'元',
						'currencies_rate'=>'1.0000',
						'currencies_long'=>'2',
						'language_id'=>'1',
					)
);
?>