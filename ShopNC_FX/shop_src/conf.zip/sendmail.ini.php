<?php
$INFO['websit']['mailtype']='smtp';
$INFO['websit']['smtpserver']='smtp.163.com';
$INFO['websit']['smtpemail']='wangdebin_10@163.com';
$INFO['websit']['smtpprot']='25';
$INFO['websit']['mailto']='shopnc@shopnc.cn';
$INFO['websit']['smtppass']='123456';
$INFO['websit']['new_user_mail']='0';
$INFO['websit']['buy_goods_mail']='0';
$INFO['websit']['del_goods_mail']='0';
$INFO['websit']['pay_mail']='0';
$INFO['websit']['send_goods_mail']='0';
$INFO['websit']['end_goods_mail']='0';
?>