<?php
$INFO['interface']['open_passport']='0';
$INFO['interface']['open_ucenter']='1';
$INFO['interface']['passport_key']='222222';
$INFO['interface']['uc_dbhost']='localhost';
$INFO['interface']['uc_dbname']='zhengheshiyan';
$INFO['interface']['uc_dbuser']='root';
$INFO['interface']['uc_dbpw']='root';
$INFO['interface']['uc_dbtablepre']='uc_';
$INFO['interface']['uc_dbcharset']='utf-8';
$INFO['interface']['uc_api']='http://127.0.0.1/zhengheshiyan/upload/ucenter';
$INFO['interface']['uc_charset']='utf-8';
$INFO['interface']['uc_ip']='127.0.0.1';
$INFO['interface']['uc_appid']='4';
$INFO['interface']['uc_ppp']='20';
$INFO['interface']['uc_link']='true';
$INFO['interface']['discuz_path']='';
$INFO['interface']['phpwind_path']='';
$INFO['interface']['dedecms_path']='';
?>