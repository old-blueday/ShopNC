<?php
$INFO['websit']['site_name']	= "---sitename---";
$INFO['websit']['shop_user']	= "斌子";
$INFO['websit']['admin_language']	= "---language---";
$INFO['websit']['user_sex']	= "1";
$INFO['websit']['versionarea']	= "---language---";
$INFO['websit']['shop_email']	= "---shopemaill---";
$INFO['websit']['shop_currency']	= "---currency_id---";
$INFO['websit']['shop_call']	= "022-27260105";
$INFO['websit']['shop_state']	= "1";
$INFO['websit']['time_zone']	= "0";
$INFO['websit']['shop_address']	= "天津市南开区西北角";
$INFO['websit']['shop_copyright']	= "ShopNC&reg;天津网城科技有限公司<br>Copyright&copy; 2007-2009 ShopNC, Powered by <a href=http://www.shopnc.net>ShopNC</a> Team , All Rights Reserved";
$INFO['websit']['shop_post']	= "300120";
$INFO['websit']['shop_ipc']	= "津ICP备08000171号";
$INFO['websit']['shop_keywords']	= "网店，商店，商城，电子商务，网上购物";
$INFO['websit']['shop_description']	= "大家一起来购物，通过电子商务上网选择商品更方便，使您感受足不出户浏览天下商品的乐趣，这就是电子商务，网上商店给你带来的好处，快来加入网上商店的行列中来吧！";
$INFO['websit']['site_url']	= "---siteurl---";
$INFO['websit']['nc_charset']	= "---nc_charset---";
$INFO['websit']['templatesname']	= "---templates---";
$INFO['websit']['shop_logo_file']	= "";
$INFO['websit']['currencies']	= "1";
$INFO['websit']['shop_fax']	= "022-27260105";
?>