$(document).ready(function() {
    $("#vote").sexyVote();
});